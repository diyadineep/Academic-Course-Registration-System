// File: src/entities/Course.java
package entities;

import java.util.*;
import data.WaitlistQueue;
import java.util.stream.Collectors;


public class Course {
    private String courseCode;
    private String courseName;
    private int maxCapacity;
    private List<Student> enrolledStudents;
    private WaitlistQueue waitlist;
    private List<String> prerequisites;


    public Course() {
        this.enrolledStudents = new ArrayList<>();
        this.waitlist = new WaitlistQueue();
        this.prerequisites = new ArrayList<>();
    }

    // Getters and Setters
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public int getMaxCapacity() { return maxCapacity; }
    public void setMaxCapacity(int maxCapacity) { this.maxCapacity = maxCapacity; }

    public List<Student> getEnrolledStudents() { return enrolledStudents; }
    public void setEnrolledStudents(List<Student> enrolledStudents) { this.enrolledStudents = enrolledStudents; }

    public WaitlistQueue getWaitlist() { return waitlist; }
    public void setWaitlist(WaitlistQueue waitlist) { this.waitlist = waitlist; }

    public List<String> getPrerequisites() { return prerequisites; }
    public void setPrerequisites(List<String> prerequisites) { this.prerequisites = prerequisites; }

    public void addPrerequisite(String prerequisiteCourse) {
        if (!this.prerequisites.contains(prerequisiteCourse)) {
            this.prerequisites.add(prerequisiteCourse);
        }
    }

    public void enrollStudent(Student student) {
        if (this.enrolledStudents.size() < this.maxCapacity) {
            this.enrolledStudents.add(student);
            System.out.println(student.getFullName() + " successfully enrolled in " + this.courseName + ".");
        } else {
            this.waitlist.enqueue(student);
            System.out.println("Course full! " + student.getFullName() + " added to waitlist for " + this.courseName + ".");
        }
    }

    public void dropStudent(Student student) {
        if (this.enrolledStudents.contains(student)) {
            this.enrolledStudents.remove(student);
            System.out.println(student.getFullName() + " dropped from " + this.courseName + ".");

            if (!this.waitlist.isEmpty()) {
                Student nextStudent = this.waitlist.dequeue();
                this.enrolledStudents.add(nextStudent);
                System.out.println(nextStudent.getFullName() + " enrolled from waitlist into " + this.courseName + ".");
            }
        } else {
            System.out.println(student.getFullName() + " is not enrolled in " + this.courseName + ".");
        }
    }

    public void viewCourseDetails() {
        System.out.println("\nCourse: " + this.courseName + " (" + this.courseCode + ")");
        System.out.println("Capacity: " + this.enrolledStudents.size() + "/" + this.maxCapacity);
        System.out.print("Prerequisites: ");
        if (this.prerequisites.isEmpty()) {
            System.out.println("None");
        } else {
            System.out.println(String.join(", ", this.prerequisites));
        }

        System.out.print("Enrolled Students: ");
        if (this.enrolledStudents.isEmpty()) {
            System.out.println("None");
        } else {
            List<String> studentNames = this.enrolledStudents.stream()
                    .map(Student::getFullName)
                    .collect(Collectors.toList());
            System.out.println(String.join(", ", studentNames));
        }
    }
}
