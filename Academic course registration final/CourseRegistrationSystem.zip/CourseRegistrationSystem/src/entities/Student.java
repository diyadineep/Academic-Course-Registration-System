// File: src/entities/Student.java
package entities;

import java.util.*;
import java.util.regex.Pattern;

public class Student {
    private String studentId;
    private String fullName;
    private String gender;
    private String dob;
    private String email;
    private String socialStatus;
    private String aadhaar;
    private String state;
    private String district;
    private String city;
    private String address1;
    private String address2;
    private List<String> registeredCourses;

    public Student() {
        this.registeredCourses = new ArrayList<>();
    }

    // Getters and Setters
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getDob() { return dob; }
    public void setDob(String dob) { this.dob = dob; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSocialStatus() { return socialStatus; }
    public void setSocialStatus(String socialStatus) { this.socialStatus = socialStatus; }

    public String getAadhaar() { return aadhaar; }
    public void setAadhaar(String aadhaar) { this.aadhaar = aadhaar; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getAddress1() { return address1; }
    public void setAddress1(String address1) { this.address1 = address1; }

    public String getAddress2() { return address2; }
    public void setAddress2(String address2) { this.address2 = address2; }

    public List<String> getRegisteredCourses() { return registeredCourses; }
    public void setRegisteredCourses(List<String> registeredCourses) { this.registeredCourses = registeredCourses; }

    public void registerCourse(String course) {
        if (!this.registeredCourses.contains(course)) {
            this.registeredCourses.add(course);
            System.out.println(this.fullName + " successfully registered for " + course + ".");
        } else {
            System.out.println(this.fullName + " is already registered for " + course + ".");
        }
    }

    public void dropCourse(String course) {
        if (this.registeredCourses.contains(course)) {
            this.registeredCourses.remove(course);
            System.out.println(this.fullName + " dropped " + course + ".");
        } else {
            System.out.println(this.fullName + " is not registered for " + course + ".");
        }
    }

    public void viewRegisteredCourses() {
        if (!this.registeredCourses.isEmpty()) {
            System.out.print(this.fullName + "'s Registered Courses: ");
            System.out.println(String.join(", ", this.registeredCourses));
        } else {
            System.out.println(this.fullName + " is not registered for any courses.");
        }
    }

    public void displayStudentDetails() {
        System.out.println("\n--- Student Details ---");
        System.out.println("Student ID: " + this.studentId);
        System.out.println("Full Name: " + this.fullName);
        System.out.println("Gender: " + this.gender);
        System.out.println("Date of Birth: " + this.dob);
        System.out.println("Email: " + this.email);
        System.out.println("Social Status: " + this.socialStatus);
        System.out.println("Aadhaar: " + this.aadhaar);
        System.out.println("Address: " + this.address1 + ", " + this.address2);
        System.out.println("City: " + this.city);
        System.out.println("District: " + this.district);
        System.out.println("State: " + this.state);
    }

    
    
 }
