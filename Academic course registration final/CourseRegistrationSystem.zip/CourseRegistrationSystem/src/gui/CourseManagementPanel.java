// File: src/gui/CourseManagementPanel.java
package gui;

import data.CourseBST;
import data.PrerequisiteGraph;
import entities.Course; // Import Course class
import javax.swing.*;
import java.awt.*;

class CourseManagementPanel extends JPanel {
    private final JTextField courseCodeField = new JTextField(10);
    private final JTextField courseNameField = new JTextField(20);
    private final JSpinner capacitySpinner = new JSpinner(new SpinnerNumberModel(30, 5, 200, 1));
    private final CourseBST courseBST;
    private final PrerequisiteGraph prerequisiteGraph;
    private final EnrollmentPanel enrollmentPanel;

    public CourseManagementPanel(CourseBST courseBST, PrerequisiteGraph prerequisiteGraph, EnrollmentPanel enrollmentPanel) {
        this.courseBST = courseBST;
        this.prerequisiteGraph = prerequisiteGraph;
        this.enrollmentPanel = enrollmentPanel;

        setLayout(new GridLayout(0, 2));

        addField("Course Code:", courseCodeField);
        addField("Course Name:", courseNameField);
        addField("Capacity:", capacitySpinner);

        JButton addButton = new JButton("Add Course");
        addButton.addActionListener(e -> addCourse());
        add(addButton);
    }

    private void addField(String label, JComponent field) {
        add(new JLabel(label));
        add(field);
    }

    private void addCourse() {
        String courseCode = courseCodeField.getText();
        String courseName = courseNameField.getText();
        int capacity = (int) capacitySpinner.getValue();

        if (!isValidCourseCode(courseCode) || !isValidCourseName(courseName) || !isValidCapacity(capacity)) {
            return; // Exit if any validation fails
        }

        Course course = new Course();
        course.setCourseCode(courseCode);
        course.setCourseName(courseName);
        course.setMaxCapacity(capacity);

        courseBST.insert(course);
        prerequisiteGraph.addCourse(course.getCourseCode());
        enrollmentPanel.updateCourseList();

        JOptionPane.showMessageDialog(this, "Course Added!");
    }

    private boolean isValidCourseCode(String courseCode) {
        if (!courseCode.matches("^[A-Z]{2,4}\\d{3,4}$")) {
            JOptionPane.showMessageDialog(this, "Invalid Course Code! Format: DepartmentCode+Number (e.g., CS101, MATH2001)");
            return false;
        }
        return true;
    }

    private boolean isValidCourseName(String courseName) {
        if (courseName.length() < 5 || !courseName.matches("^[A-Za-z0-9 &\\-]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid Course Name! Must be at least 5 characters (letters, numbers, spaces, &, -)");
            return false;
        }
        return true;
    }

    private boolean isValidCapacity(int capacity) {
        if (capacity < 5 || capacity > 200) {
            JOptionPane.showMessageDialog(this, "Capacity must be between 5 and 200");
            return false;
        }
        return true;
    }

    public String getCourseCode() {
        return courseCodeField.getText();
    }
}
