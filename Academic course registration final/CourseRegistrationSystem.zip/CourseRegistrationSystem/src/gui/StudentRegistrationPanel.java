// File: src/gui/StudentRegistrationPanel.java
package gui;

import entities.Student; // Import Student class
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.regex.Pattern;

class StudentRegistrationPanel extends JPanel {

    private final JTextField studentIdField = new JTextField(15);
    private final JTextField fullNameField = new JTextField(20);
    private final JComboBox<String> genderBox = new JComboBox<>(new String[]{"M", "F", "O"});
    private final JTextField dobField = new JTextField(10);
    private final JTextField emailField = new JTextField(20);
    private final JComboBox<String> socialStatusBox = new JComboBox<>(new String[]{"GEN", "OBC", "SC", "ST", "EWS"});
    private final JTextField aadhaarField = new JTextField(12);
    private final JTextField stateField = new JTextField(15);
    private final JTextField districtField = new JTextField(15);
    private final JTextField cityField = new JTextField(15);
    private final JTextField address1Field = new JTextField(30);
    private final JTextField address2Field = new JTextField(30);
    private final List<Student> students;
    private final EnrollmentPanel enrollmentPanel;

    public StudentRegistrationPanel(List<Student> students, EnrollmentPanel enrollmentPanel) {
        this.students = students;
        this.enrollmentPanel = enrollmentPanel;

        setLayout(new GridLayout(0, 2, 5, 5));

        addField("Student ID:", studentIdField);
        addField("Full Name:", fullNameField);
        addField("Gender:", genderBox);
        addField("Date of Birth (DD-MM-YYYY):", dobField);
        addField("Email:", emailField);
        addField("Social Status:", socialStatusBox);
        addField("Aadhaar Number:", aadhaarField);
        addField("State:", stateField);
        addField("District:", districtField);
        addField("City:", cityField);
        addField("Address Line 1:", address1Field);
        addField("Address Line 2:", address2Field);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(e -> registerStudent());
        add(registerButton);
    }

    private void addField(String label, JComponent field) {
        add(new JLabel(label));
        add(field);
    }

    private void registerStudent() {
        if (isValidInput()) {
            Student student = createStudent();
            students.add(student);
            enrollmentPanel.updateStudentList();
            JOptionPane.showMessageDialog(this, "Registration Successful!");
            clearFields();
        }
    }

    private boolean isValidInput() {
        return isValidStudentId() && isValidFullName() && isValidEmail() &&
                isValidDOB() && isValidAadhaar() && isValidSocialStatus() && isValidGender();
    }

    private Student createStudent() {
        Student student = new Student();
        student.setStudentId(studentIdField.getText());
        student.setFullName(fullNameField.getText());
        student.setGender((String) genderBox.getSelectedItem());
        student.setDob(dobField.getText());
        student.setEmail(emailField.getText());
        student.setSocialStatus((String) socialStatusBox.getSelectedItem());
        student.setAadhaar(aadhaarField.getText());
        student.setState(stateField.getText());
        student.setDistrict(districtField.getText());
        student.setCity(cityField.getText());
        student.setAddress1(address1Field.getText());
        student.setAddress2(address2Field.getText());
        return student;
    }

    private void clearFields() {
        studentIdField.setText("");
        fullNameField.setText("");
        genderBox.setSelectedIndex(0);
        dobField.setText("");
        emailField.setText("");
        socialStatusBox.setSelectedIndex(0);
        aadhaarField.setText("");
        stateField.setText("");
        districtField.setText("");
        cityField.setText("");
        address1Field.setText("");
        address2Field.setText("");
    }

    private boolean isValidStudentId() {
        String studentId = studentIdField.getText();
        if (!studentId.matches("^[A-Za-z0-9]{8,12}$")) {
            JOptionPane.showMessageDialog(this, "Invalid Student ID! Must be 8-12 alphanumeric characters.");
            return false;
        }
        return true;
    }

    private boolean isValidFullName() {
        String fullName = fullNameField.getText();
        if (!fullName.matches("^[A-Za-z ]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid Name! Only letters and spaces allowed.");
            return false;
        }
        return true;
    }

    private boolean isValidGender() {
        String gender = (String) genderBox.getSelectedItem();
        if (!gender.matches("^[MFO]$")) {
            JOptionPane.showMessageDialog(this, "Invalid Gender! Must be M, F, or O.");
            return false;
        }
        return true;
    }

    private boolean isValidDOB() {
        String dob = dobField.getText();
        if (!dob.matches("^\\d{2}-\\d{2}-\\d{4}$")) {
            JOptionPane.showMessageDialog(this, "Invalid Date of Birth! Use DD-MM-YYYY format.");
            return false;
        }
        return true;
    }

    private boolean isValidEmail() {
        String email = emailField.getText();
        if (!email.matches("^[^@]+@[^@]+\\.[^@]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid Email! Must be in format user@domain.com");
            return false;
        }
        return true;
    }

    private boolean isValidSocialStatus() {
        String socialStatus = (String) socialStatusBox.getSelectedItem();
        if (!socialStatus.matches("^(GEN|OBC|SC|ST|EWS)$")) {
            JOptionPane.showMessageDialog(this, "Invalid Social Status! Must be GEN/OBC/SC/ST/EWS.");
            return false;
        }
        return true;
    }

    private boolean isValidAadhaar() {
        String aadhaar = aadhaarField.getText();
        if (!aadhaar.matches("^\\d{12}$")) {
            JOptionPane.showMessageDialog(this, "Invalid Aadhaar! Must be 12 digits.");
            return false;
        }
        return true;
    }

    public String getStudentId() {
        return studentIdField.getText();
    }

    public String getFullName() {
        return fullNameField.getText();
    }
}
