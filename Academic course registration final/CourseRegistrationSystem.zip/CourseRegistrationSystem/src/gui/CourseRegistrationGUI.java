// File: src/gui/CourseRegistrationGUI.java
package gui;

import data.CourseBST;
import data.PrerequisiteGraph;
import entities.Student;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CourseRegistrationGUI extends JFrame {
    private final List<Student> students = new ArrayList<>();
    private final CourseBST courseBST = new CourseBST();
    private final PrerequisiteGraph prerequisiteGraph = new PrerequisiteGraph();
    private final EnrollmentPanel enrollmentPanel;

    public CourseRegistrationGUI() {
        setTitle("Course Registration System");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        enrollmentPanel = new EnrollmentPanel(students, courseBST);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Student Registration", new StudentRegistrationPanel(students, enrollmentPanel));
        tabbedPane.addTab("Course Management", new CourseManagementPanel(courseBST, prerequisiteGraph, enrollmentPanel));
        tabbedPane.addTab("Enrollment", enrollmentPanel);
        tabbedPane.addTab("Prerequisites", new PrerequisitePanel(prerequisiteGraph, courseBST));

        add(tabbedPane);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CourseRegistrationGUI::new);
    }
}
