// File: src/gui/WaitlistPanel.java
package gui;

import data.CourseBST;
import entities.Course; // Import Course class
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;
import data.WaitlistQueue;
import entities.Student;

class WaitlistPanel extends JPanel {
    private final JComboBox<String> courseCombo;
    private final JList<String> waitlistList = new JList<>();
    private final CourseBST courseBST;


    public WaitlistPanel(CourseBST courseBST) {
	this.courseBST = courseBST;
        courseCombo = new JComboBox<>(getAllCourseCodes(courseBST));

        courseCombo.addActionListener(e -> updateWaitlist());

        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(new JLabel("Select Course:"));
        topPanel.add(courseCombo);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(waitlistList), BorderLayout.CENTER);
    }

    private String[] getAllCourseCodes(CourseBST courseBST) {
        List<Course> courses = courseBST.getAllCourses();
        List<String> courseCodes = courses.stream()
                .map(Course::getCourseCode)
                .collect(Collectors.toList());
        return courseCodes.toArray(new String[0]);
    }

    private void updateWaitlist() {
        String selectedCourseCode = (String) courseCombo.getSelectedItem();
        if (selectedCourseCode == null) {
            return;
        }

        Course selectedCourse = courseBST.search(selectedCourseCode);
        if (selectedCourse != null) {
            WaitlistQueue waitlist = selectedCourse.getWaitlist();
            List<Student> waitlistedStudents = waitlist.getAllStudents();

            DefaultListModel<String> model = new DefaultListModel<>();
            for (Student student : waitlistedStudents) {
                model.addElement(student.getFullName());
            }
            waitlistList.setModel(model);
        } else {
            JOptionPane.showMessageDialog(this, "Course not found.");
        }
    }
}
