// File: src/gui/EnrollmentPanel.java
package gui;

import data.CourseBST;
import entities.Student;
import entities.Course;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EnrollmentPanel extends JPanel {
    private final JComboBox<String> studentCombo = new JComboBox<>();
    private final JComboBox<String> courseCombo = new JComboBox<>();
    private final DefaultListModel<String> enrolledListModel = new DefaultListModel<>();
    private final JList<String> enrolledList = new JList<>(enrolledListModel);
    private final CourseBST courseBST;
    private final List<Student> students;

    public EnrollmentPanel(List<Student> students, CourseBST courseBST) {
        this.students = students;
        this.courseBST = courseBST;

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        add(new JLabel("Select Student:"), gbc);
        gbc.gridy++;
        add(studentCombo, gbc);
        gbc.gridy++;
        add(new JLabel("Select Course:"), gbc);
        gbc.gridy++;
        add(courseCombo, gbc);
        gbc.gridy++;

        JButton enrollButton = new JButton("Enroll Student");
        enrollButton.addActionListener(e -> enrollStudent());
        add(enrollButton, gbc);
        gbc.gridy++;

        JButton dropButton = new JButton("Drop Student");
        dropButton.addActionListener(e -> dropStudent());
        add(dropButton, gbc);
        gbc.gridy++;

        add(new JLabel("Enrolled Students:"), gbc);
        gbc.gridy++;
        enrolledList.setPreferredSize(new Dimension(200, 150));
        add(new JScrollPane(enrolledList), gbc);

        updateStudentList();
        updateCourseList();
    }

    public void updateStudentList() {
        studentCombo.removeAllItems();
        for (Student student : students) {
            studentCombo.addItem(student.getFullName());
        }
    }

    public void updateCourseList() {
        courseCombo.removeAllItems();
        List<Course> courses = courseBST.getAllCourses();
        for (Course course : courses) {
            courseCombo.addItem(course.getCourseCode());
        }
    }

    private void enrollStudent() {
        String selectedStudentName = (String) studentCombo.getSelectedItem();
        String selectedCourseCode = (String) courseCombo.getSelectedItem();

        if (selectedStudentName == null || selectedCourseCode == null) {
            JOptionPane.showMessageDialog(this, "Please select both a student and a course.");
            return;
        }

        Student selectedStudent = null;
        for (Student student : students) {
            if (student.getFullName().equals(selectedStudentName)) {
                selectedStudent = student;
                break;
            }
        }

        Course selectedCourse = courseBST.search(selectedCourseCode);

        if (selectedStudent != null && selectedCourse != null) {
            selectedCourse.enrollStudent(selectedStudent);
            updateEnrolledList(selectedCourse);
            JOptionPane.showMessageDialog(this, selectedStudentName + " enrolled in " + selectedCourseCode);
        } else {
            JOptionPane.showMessageDialog(this, "Enrollment failed. Check student and course.");
        }
    }

    private void dropStudent() {
        String selectedStudentName = (String) studentCombo.getSelectedItem();
        String selectedCourseCode = (String) courseCombo.getSelectedItem();

        if (selectedStudentName == null || selectedCourseCode == null) {
            JOptionPane.showMessageDialog(this, "Please select both a student and a course.");
            return;
        }

        Student selectedStudent = null;
        for (Student student : students) {
            if (student.getFullName().equals(selectedStudentName)) {
                selectedStudent = student;
                break;
            }
        }

        Course selectedCourse = courseBST.search(selectedCourseCode);

        if (selectedStudent != null && selectedCourse != null) {
            selectedCourse.dropStudent(selectedStudent);
            updateEnrolledList(selectedCourse);
            JOptionPane.showMessageDialog(this, selectedStudentName + " dropped from " + selectedCourseCode);
        } else {
            JOptionPane.showMessageDialog(this, "Drop failed. Check student and course.");
        }
    }

    private void updateEnrolledList(Course course) {
        enrolledListModel.clear();
        if (course != null) {
            List<Student> enrolled = course.getEnrolledStudents();
            for (Student student : enrolled) {
                enrolledListModel.addElement(student.getFullName());
            }
        }
    }
}
