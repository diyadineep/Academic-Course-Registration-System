// File: src/gui/CourseDetailsViewer.java
package gui;

import entities.Course; // Import Course class
import javax.swing.*;
import java.awt.*;

class CourseDetailsViewer extends JPanel {
    private final JTextArea courseDetailsArea = new JTextArea(10, 30);

    public CourseDetailsViewer() {
        setLayout(new BorderLayout());
        courseDetailsArea.setEditable(false);
        add(new JScrollPane(courseDetailsArea), BorderLayout.CENTER);
    }

    public void displayCourseDetails(Course course) {
        if (course == null) {
            courseDetailsArea.setText("No course selected.");
            return;
        }

        StringBuilder details = new StringBuilder();
        details.append("Course Code: ").append(course.getCourseCode()).append("\n");
        details.append("Course Name: ").append(course.getCourseName()).append("\n");
        details.append("Max Capacity: ").append(course.getMaxCapacity()).append("\n");
        details.append("Enrolled Students: ").append(course.getEnrolledStudents().size()).append("\n");
        details.append("Prerequisites: ").append(String.join(", ", course.getPrerequisites())).append("\n");

        courseDetailsArea.setText(details.toString());
    }
}
