// File: src/gui/PrerequisitePanel.java
package gui;

import data.CourseBST;
import data.PrerequisiteGraph;
import entities.Course; // Import Course class
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

class PrerequisitePanel extends JPanel {
    private final JComboBox<String> courseCombo;
    private final JList<String> prerequisiteList = new JList<>();
    private final PrerequisiteGraph graph;
    private final CourseBST courseBST;

    public PrerequisitePanel(PrerequisiteGraph graph, CourseBST courseBST) {
        this.graph = graph;
        this.courseBST = courseBST;

        courseCombo = new JComboBox<>(getAllCourseCodes());

        JButton addButton = new JButton("Add Prerequisite");
        addButton.addActionListener(e -> addPrerequisite());

        courseCombo.addActionListener(e -> updatePrerequisiteList());

        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(new JLabel("Select Course:"));
        topPanel.add(courseCombo);
        topPanel.add(addButton);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(prerequisiteList), BorderLayout.CENTER);
    }

    private String[] getAllCourseCodes() {
        List<Course> courses = courseBST.getAllCourses();
        List<String> courseCodes = courses.stream()
                .map(Course::getCourseCode)
                .collect(Collectors.toList());
        return courseCodes.toArray(new String[0]);
    }

    private void addPrerequisite() {
        String selectedCourseCode = (String) courseCombo.getSelectedItem();
        if (selectedCourseCode == null) {
            JOptionPane.showMessageDialog(this, "Please select a course.");
            return;
        }

        String prerequisiteCourseCode = (String) JOptionPane.showInputDialog(
                this,
                "Enter Prerequisite Course Code:",
                "Add Prerequisite",
                JOptionPane.PLAIN_MESSAGE,
                null,
                getAllCourseCodes(),
                null
        );

        if (prerequisiteCourseCode != null && !prerequisiteCourseCode.isEmpty()) {
            graph.addPrerequisite(selectedCourseCode, prerequisiteCourseCode);
            if (graph.hasCycle()) {
                JOptionPane.showMessageDialog(this, "Cycle detected! Operation rejected.");
                graph.removePrerequisite(selectedCourseCode, prerequisiteCourseCode);
            }
            updatePrerequisiteList();
        }
    }

    private void updatePrerequisiteList() {
        String selectedCourseCode = (String) courseCombo.getSelectedItem();
        if (selectedCourseCode == null) {
            return;
        }

        List<String> prerequisites = graph.getPrerequisites(selectedCourseCode);
        DefaultListModel<String> model = new DefaultListModel<>();
        for (String prereq : prerequisites) {
            model.addElement(prereq);
        }
        prerequisiteList.setModel(model);
    }
}
