// File: src/gui/StudentDetailsViewer.java
package gui;

import entities.Student; // Import Student class
import javax.swing.*;
import java.awt.*;
import java.util.List;

class StudentDetailsViewer extends JPanel {
    private final JTextArea studentDetailsArea = new JTextArea(10, 30);

    public StudentDetailsViewer() {
        setLayout(new BorderLayout());
        studentDetailsArea.setEditable(false);
        add(new JScrollPane(studentDetailsArea), BorderLayout.CENTER);
    }

    public void displayStudentDetails(Student student) {
        if (student == null) {
            studentDetailsArea.setText("No student selected.");
            return;
        }

        StringBuilder details = new StringBuilder();
        details.append("Student ID: ").append(student.getStudentId()).append("\n");
        details.append("Full Name: ").append(student.getFullName()).append("\n");
        details.append("Gender: ").append(student.getGender()).append("\n");
        details.append("Date of Birth: ").append(student.getDob()).append("\n");
        details.append("Email: ").append(student.getEmail()).append("\n");
        details.append("Social Status: ").append(student.getSocialStatus()).append("\n");
        details.append("Aadhaar: ").append(student.getAadhaar()).append("\n");
        details.append("Address: ").append(student.getAddress1()).append(", ").append(student.getAddress2()).append("\n");
        details.append("City: ").append(student.getCity()).append("\n");
        details.append("District: ").append(student.getDistrict()).append("\n");
        details.append("State: ").append(student.getState()).append("\n");
        studentDetailsArea.setText(details.toString());
    }
}
