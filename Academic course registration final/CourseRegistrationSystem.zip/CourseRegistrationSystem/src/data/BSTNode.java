// File: src/data/BSTNode.java
package data;

import entities.Course; // Import Course class

class BSTNode {
    Course course;
    BSTNode left, right;

    public BSTNode(Course course) {
        this.course = course;
        this.left = this.right = null;
    }
}
