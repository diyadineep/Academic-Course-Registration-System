// File: src/data/PrerequisiteGraph.java
package data;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

public class PrerequisiteGraph {
    private Map<String, List<String>> adjList;

    public PrerequisiteGraph() {
        this.adjList = new HashMap<>();
    }

    public void addCourse(String courseCode) {
        adjList.putIfAbsent(courseCode, new ArrayList<>());
    }

    public void addPrerequisite(String courseCode, String prereqCode) {
        adjList.get(courseCode).add(prereqCode);
    }

    public List<String> getPrerequisites(String courseCode) {
        return adjList.getOrDefault(courseCode, new ArrayList<>());
    }

    public boolean hasCycle() {
        Set<String> visited = new HashSet<>();
        Set<String> recursionStack = new HashSet<>();

        for (String course : adjList.keySet()) {
            if (hasCycleUtil(course, visited, recursionStack)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasCycleUtil(String course, Set<String> visited, Set<String> recursionStack) {
        if (recursionStack.contains(course)) return true;
        if (visited.contains(course)) return false;

        visited.add(course);
        recursionStack.add(course);

        for (String neighbor : adjList.get(course)) {
            if (hasCycleUtil(neighbor, visited, recursionStack)) {
                return true;
            }
        }

        recursionStack.remove(course);
        return false;
    }

    public void removePrerequisite(String courseCode, String prerequisiteCourseCode) {
         if (adjList.containsKey(courseCode)) {
             adjList.get(courseCode).remove(prerequisiteCourseCode);
         }
    }
}
