// File: src/data/WaitlistQueue.java
package data;

import entities.Student; // Import Student class
import java.util.List;
import java.util.ArrayList;

public class WaitlistQueue {
    private static class Node {
        Student student;
        Node next;

        public Node(Student student) {
            this.student = student;
            this.next = null;
        }
    }

    private Node front, rear;

    public void enqueue(Student student) {
        Node newNode = new Node(student);
        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public Student dequeue() {
        if (front == null) return null;

        Student student = front.student;
        front = front.next;

        if (front == null) {
            rear = null;
        }
        return student;
    }

    public boolean isEmpty() {
        return front == null;
    }

    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        Node current = front;
        while (current != null) {
            students.add(current.student);
            current = current.next;
        }
        return students;
    }
}
