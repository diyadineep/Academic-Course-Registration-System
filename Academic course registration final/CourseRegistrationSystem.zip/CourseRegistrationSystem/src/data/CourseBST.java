// File: src/data/CourseBST.java
package data;

import entities.Course; // Import Course class
import java.util.List;
import java.util.ArrayList;

public class CourseBST {
    private BSTNode root;

    public void insert(Course course) {
        root = insertRec(root, course);
    }

    private BSTNode insertRec(BSTNode node, Course course) {
        if (node == null) {
            return new BSTNode(course);
        }

        if (course.getCourseCode().compareTo(node.course.getCourseCode()) < 0) {
            node.left = insertRec(node.left, course);
        } else {
            node.right = insertRec(node.right, course);
        }

        return node;
    }

    public Course search(String courseCode) {
        return searchRec(root, courseCode);
    }

    private Course searchRec(BSTNode node, String courseCode) {
        if (node == null) {
            return null;
        }

        if (courseCode.equals(node.course.getCourseCode())) {
            return node.course;
        }

        return courseCode.compareTo(node.course.getCourseCode()) < 0
                ? searchRec(node.left, courseCode)
                : searchRec(node.right, courseCode);
    }

    public void inOrderTraversal() {
        inOrderRec(root);
    }

    private void inOrderRec(BSTNode node) {
        if (node != null) {
            inOrderRec(node.left);
            node.course.viewCourseDetails();
            inOrderRec(node.right);
        }
    }
    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        inOrderRec(root, courses);
        return courses;
    }

    private void inOrderRec(BSTNode node, List<Course> courses) {
        if (node != null) {
            inOrderRec(node.left, courses);
            courses.add(node.course);
            inOrderRec(node.right, courses);
        }
    }
}
